/*
 * stateMachine.cpp
 *
 * Created: 02.10.2017 17:03:34
 *  Author: Reiner
 */ 

#include "stateMachine.h"

const state_desc_t PROGMEM states[]= {
	{ST_IDLE,	DISP_KONTEXT_NONE,	I_NONE,	V_NONE,	A_GET_BUTTONS},
	{ST_IDLE,	DISP_KONTEXT_NONE,	I_BTN,	V_BTN0,	A_NEXT_DISPLAY},
	{ST_IDLE,	DISP_KONTEXT_NONE,	I_BTN,	V_BTN4,	A_CUT_OFF_INC},
	{ST_IDLE,	DISP_KONTEXT_NONE,	I_BTN,	V_BTN5,	A_CUT_OFF_DEC},
	{ST_IDLE,	DISP_KONTEXT_IDLE,	I_BTN,	V_BTN3,	A_UHRZEIT_GITTER},
	{ST_IDLE,	DISP_KONTEXT_IDLE,	I_BTN,	V_BTN1,	A_SHORT_CDWN_60},
	{ST_IDLE,	DISP_KONTEXT_IDLE,	I_BTN,	V_BTN2,	A_SHORT_CDWN_120},
	{ST_IDLE,	DISP_KONTEXT_CDWN1,	I_BTN,	V_BTN1,	A_CDWN_MIN_UP},
	{ST_IDLE,	DISP_KONTEXT_CDWN1,	I_BTN,	V_BTN2,	A_CDWN_SEC_UP},
	{ST_IDLE,	DISP_KONTEXT_CDWN1,	I_BTN,	V_BTN3,	A_CDWM_START},
	{ST_IDLE,   DISP_KONTEXT_CDWN2,	I_NONE,	V_NONE,	A_CDWM_UPDATE},
	{ST_IDLE,	DISP_KONTEXT_CDWN2,	I_AUTO_DONE,	V_NONE,	A_CDWM_END},
	{ST_IDLE,   DISP_KONTEXT_CDWN3,	I_NONE,	V_NONE,	A_CDWM_UPDATE},
	{ST_IDLE,	DISP_KONTEXT_CDWN3,	I_AUTO_DONE,	V_NONE,	A_GO_IDLE},
	{ST_IDLE,	DISP_KONTEXT_UHRZEIT_SET,	I_BTN,	V_BTN1,	A_TIMESET_NEXT},
	{ST_IDLE,	DISP_KONTEXT_UHRZEIT_SET,	I_BTN,	V_BTN2,	A_TIMESET_UP},
	{ST_IDLE,	DISP_KONTEXT_UHRZEIT_SET,	I_BTN,	V_BTN3,	A_TIMESET_DOWN},
	{ST_IDLE,	DISP_KONTEXT_RPM,	I_HDDCMDRUN,	CMD_NONE,	A_CLEAR_AUTOACTION},
	{ST_IDLE,	DISP_KONTEXT_RPM,	I_BTN,	V_BTN1,	A_HDD_SPEED_UP},
	{ST_IDLE,	DISP_KONTEXT_RPM,	I_BTN,	V_BTN2,	A_HDD_SPEED_DOWN},
	{ST_IDLE,	DISP_KONTEXT_RPM,	I_BTN,	V_BTN3,	A_HDD_CALIBRATION}

};

state_control_t myStateMachine;
extern volatile hddClockControl_t myClockControl;
extern hdd_uhr_settings_t myClockSettings;

uint8_t stateMax() {
	return sizeof(states)/sizeof(state_desc_t)-1;
}

void getStateDesc (uint8_t stateNdx, state_desc_t *dest) {
	if (stateNdx>stateMax()) stateNdx=0;
	const PROGMEM state_desc_t* src=&states[stateNdx];
	memcpy_P(dest,src,sizeof(state_desc_t));
}

void stateVarsInit () {
	myStateMachine.autoActionDone=0;
	for (uint8_t i=0; i<STATE_VAR_MAX; i++)
		myStateMachine.stateVars[i]=0;
}

void stateMachineInit () {
	myStateMachine.stateNdx=0;
	myStateMachine.displayKontext=DISP_KONTEXT_IDLE;
	stateVarsInit();
}

#define STATE_OK_DISPLAY	0x01
#define STATE_OK_INPUT		0x02
#define STATE_OK_MASK		(STATE_OK_DISPLAY|STATE_OK_INPUT)

void stateMachine () {
	// N�chsten passenden State holen
	state_desc_t state;
	getStateDesc(myStateMachine.stateNdx,&state);
	
	// Sind bedingungen erf�llt?
	uint8_t stateOk=0;
	
	if (state.displayKontext==DISP_KONTEXT_NONE) stateOk|=STATE_OK_DISPLAY;
	else {
		if (state.displayKontext==myStateMachine.displayKontext) stateOk|=STATE_OK_DISPLAY;
	}
	
	if (state.inputTrigger==I_NONE) stateOk|=STATE_OK_INPUT;
	else {
		switch (state.inputTrigger) {
			case I_TIME: 
				if (millis()-myStateMachine.lastTimestamp>state.inputValue) stateOk|=STATE_OK_INPUT;
				break;
			case I_AUTO_DONE:
				if (myStateMachine.autoActionDone!=0) {
					stateOk|=STATE_OK_INPUT;
				}
				break;
			case I_BTN:
				if (state.inputValue==myStateMachine.buttons) stateOk|=STATE_OK_INPUT;
				break;
			case I_BTNHOLD:
				if (state.inputValue==myStateMachine.buttonsHold) stateOk|=STATE_OK_INPUT;
				break;
			default:
				break;
		}
	}
	
	char buf[50];
	
	if (stateOk==STATE_OK_MASK) {
		switch (state.action) {
			case A_NEXT_DISPLAY:
				setDisplayNext();
				stateVarsInit();
				myStateMachine.displayKontext=getDisplayKontext();
				// Inits zu verschiedenen Display Kontexten
				switch (myStateMachine.displayKontext) {
					case DISP_KONTEXT_UHRZEIT:
						//initDisplayUhrzeit();
						break;
					case DISP_KONTEXT_CDWN1:
						//setDisplayCDWN1(0,0,true);
						break;
					case DISP_KONTEXT_CDWN2:
						//initDisplayCDWN2(0,1);
						break;
					case DISP_KONTEXT_CDWN3:
						//initDisplayCDWN3(10);
						break;
					case DISP_KONTEXT_RPM:
						myStateMachine.stateVars[0]=hddGetRpmTarget();
						setDisplayRpm(myStateMachine.stateVars[0]);
						break;
					case DISP_KONTEXT_UHRZEIT_SET:
						//
						break;
					default:
						//initDisplayDefault();
						break;
				}
				break;
			case A_SHORT_CDWN_60:
				initDisplayCDWN2(1,0);
				setDisplayKontext(DISP_KONTEXT_CDWN2);
				myStateMachine.displayKontext=getDisplayKontext();
				break;
			case A_SHORT_CDWN_120:
				initDisplayCDWN2(2,0);
				setDisplayKontext(DISP_KONTEXT_CDWN2);
				myStateMachine.displayKontext=getDisplayKontext();
				break;
			case A_GET_BUTTONS:
				myStateMachine.buttons=buttonsChanged();
				myStateMachine.buttonsHold=buttonsPressed();
				break;
			case A_GET_TIMESTAMP:
				myStateMachine.lastTimestamp=millis();
				break;
			case A_HDD_SPEED_UP:
				if (myStateMachine.autoActionDone==0) {
					myStateMachine.stateVars[0]=(myStateMachine.stateVars[0]<RPM_MAX-100)?(myStateMachine.stateVars[0]/100*100)+100:RPM_MAX;
					myClockSettings.values.hddRpm=myStateMachine.stateVars[0];
					setDisplayRpm (myClockSettings.values.hddRpm);
					hddSetRpm(myClockSettings.values.hddRpm);
					settingsSave();
				}
				break;
			case A_HDD_SPEED_DOWN:
				if (myStateMachine.autoActionDone==0) {
					myStateMachine.stateVars[0]=(myStateMachine.stateVars[0]>RPM_MIN+100)?(myStateMachine.stateVars[0]/100*100)-100:RPM_MIN;
					myClockSettings.values.hddRpm=myStateMachine.stateVars[0];
					setDisplayRpm (myClockSettings.values.hddRpm);
					hddSetRpm(myClockSettings.values.hddRpm);
					settingsSave();
				}
				break;
			case A_CDWN_MIN_UP:
				myStateMachine.stateVars[1]++;
				if (myStateMachine.stateVars[1]>=60) {
					myStateMachine.stateVars[1]=0;
				}
				setDisplayCDWN1(myStateMachine.stateVars[1],myStateMachine.stateVars[0]);
				break;
			case A_CDWN_SEC_UP:
				myStateMachine.stateVars[0]+=15;
				if (myStateMachine.stateVars[0]>=60) {
					myStateMachine.stateVars[0]=0;
					myStateMachine.stateVars[1]++;
					if (myStateMachine.stateVars[1]>=60) myStateMachine.stateVars[1]=0;
				}
				setDisplayCDWN1(myStateMachine.stateVars[1],myStateMachine.stateVars[0]);
				break;
			case A_CDWM_START:
				setDisplayKontext(DISP_KONTEXT_CDWN2);
				myStateMachine.displayKontext=getDisplayKontext();
				initDisplayCDWN2(myStateMachine.stateVars[1],myStateMachine.stateVars[0]);
				break;
			case A_CDWM_END:
				myStateMachine.autoActionDone=0;
				setDisplayKontext(DISP_KONTEXT_CDWN3);
				myStateMachine.displayKontext=getDisplayKontext();
				initDisplayCDWN3(10);
				break;
			case A_GO_IDLE:
				myStateMachine.autoActionDone=0;
				setDisplayKontext(DISP_KONTEXT_IDLE);
				myStateMachine.displayKontext=getDisplayKontext();
				break;
			case A_CDWM_UPDATE:
				if (getDisplayCDWN()==0) {
					myStateMachine.autoActionDone=1;
				}
				break;
			case A_CUT_OFF_DEC:
				cutOffDec();
				break;
			case A_CUT_OFF_INC:
				cutOffInc();
				break;
			case A_TIMESET_NEXT:
				SetDisplayUhrzeitSetNext();
				break;
			case A_TIMESET_UP:
				SetDisplayUhrzeitSetUp();
				break;
			case A_TIMESET_DOWN:
				SetDisplayUhrzeitSetDown();
				break;
			case A_UHRZEIT_GITTER:
				myClockSettings.values.uhrzeitSektionen=(myClockSettings.values.uhrzeitSektionen+1)%DISP_UHRZEIT_SEKTION_MAX;
				settingsSave();
				break;
			case A_HDD_CALIBRATION:
				hddSendCmd(CMD_CALIBRATION);
				delay(500);
				myStateMachine.autoActionDone=1;
			case A_CLEAR_AUTOACTION:
				if (myStateMachine.autoActionDone!=0) {
					myStateMachine.autoActionDone=0;
				}
			default:
				break;
		}
	}
	myStateMachine.stateNdx=myStateMachine.stateNdx<stateMax()?myStateMachine.stateNdx+1:0;
}
