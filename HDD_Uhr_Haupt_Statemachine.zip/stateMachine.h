/*
 * stateMachine.h
 *
 * Created: 02.10.2017 17:03:27
 *  Author: Reiner
 */ 


#ifndef STATEMACHINE_H_
#define STATEMACHINE_H_

#include <stdlib.h>
#include <stdio.h>
#include <avr/pgmspace.h>
#include <myTimer.h>
#include "myMacros.h"
#include "defines.h"
#include "buttons.h"
#include "MAX722x.h"
#include "i2c_7seg.h"
#include "i2c_hdd.h"
#include "display.h"
#include "datatypesMotorControl.h"

#define STATE_VAR_MAX		4

typedef struct {
	uint8_t stateKontext;
	uint8_t displayKontext;
	uint8_t inputTrigger;
	uint16_t inputValue;
	uint8_t action;
} state_desc_t;

typedef struct {
	uint8_t stateNdx;
	uint8_t displayKontext;
	uint8_t autoActionDone;
	uint8_t buttons;
	uint8_t buttonsHold;
	uint32_t lastTimestamp;
	uint16_t stateVars[STATE_VAR_MAX];
} state_control_t;

// State definitionen

#define	ST_IDLE	0

#define	I_NONE	0
#define	I_TIME	1
#define	I_AUTO_DONE	2
#define	I_BTN	6
#define I_BTNHOLD	7
#define	I_HDDCMDRUN	8

#define	V_NONE	0
#define	V_BTN0	BTN0
#define	V_BTN1	BTN1
#define	V_BTN2	BTN2
#define	V_BTN3	BTN3
#define	V_BTN4	BTN4
#define	V_BTN5	BTN5

#define	A_NONE	0
#define	A_NEXT_DISPLAY	1
#define	A_SHORT_CDWN_60	2
#define	A_SHORT_CDWN_120	3
#define	A_GET_BUTTONS	4
#define	A_GET_TIMESTAMP	5
#define	A_HDD_SPEED_UP	6
#define	A_HDD_SPEED_DOWN	7
#define	A_CDWN_MIN_UP	8
#define	A_CDWN_SEC_UP	9
#define	A_CDWM_START	10
#define	A_CDWM_END	11
#define	A_GO_IDLE	12
#define	A_CDWM_UPDATE	13
#define A_CUT_OFF_INC	14
#define A_CUT_OFF_DEC	15
#define A_TIMESET_NEXT	16
#define A_TIMESET_UP	17
#define A_TIMESET_DOWN	18
#define A_UHRZEIT_GITTER	19
#define A_HDD_CALIBRATION	20
#define A_CLEAR_AUTOACTION	21

void stateMachineInit ();
void stateMachine ();

#endif /* STATEMACHINE_H_ */